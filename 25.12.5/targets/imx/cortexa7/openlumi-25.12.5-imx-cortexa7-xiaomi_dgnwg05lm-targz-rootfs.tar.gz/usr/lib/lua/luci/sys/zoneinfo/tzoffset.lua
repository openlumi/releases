-- Licensed to the public under the Apache License 2.0.

module "luci.sys.zoneinfo.tzoffset"

OFFSET = {
	gmt   =      0,	-- GMT
	eat   =  10800,	-- EAT
	cet   =   3600,	-- CET
	wat   =   3600,	-- WAT
	cat   =   7200,	-- CAT
	eet   =   7200,	-- EET
	eest  =  10800,	-- EEST
	sast  =   7200,	-- SAST
	hst   = -36000,	-- HST
	hdt   = -32400,	-- HDT
	akst  = -32400,	-- AKST
	akdt  = -28800,	-- AKDT
	ast   = -14400,	-- AST
	est   = -18000,	-- EST
	cst   = -21600,	-- CST
	mst   = -25200,	-- MST
	mdt   = -21600,	-- MDT
	pst   = -28800,	-- PST
	pdt   = -25200,	-- PDT
	nst   = -12600,	-- NST
	ndt   =  -9000,	-- NDT
	aest  =  36000,	-- AEST
	aedt  =  39600,	-- AEDT
	nzst  =  43200,	-- NZST
	nzdt  =  46800,	-- NZDT
	hkt   =  28800,	-- HKT
	wib   =  25200,	-- WIB
	wit   =  32400,	-- WIT
	ist   =   7200,	-- IST
	idt   =  10800,	-- IDT
	pkt   =  18000,	-- PKT
	wita  =  28800,	-- WITA
	kst   =  32400,	-- KST
	jst   =  32400,	-- JST
	wet   =      0,	-- WET
	acst  =  34200,	-- ACST
	acdt  =  37800,	-- ACDT
	awst  =  28800,	-- AWST
	msk   =  10800,	-- MSK
	sst   = -39600,	-- SST
}
