export const revision = '26.288.56989~75a306d', branch = 'LuCI (HEAD detached at 75a306df) branch';
